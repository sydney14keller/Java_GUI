/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.cardealer;

/**
 *
 * @author Sydney Keller <your.name at your.org>
 */
public class car {
    private String ID;
    private int year;
    private String make;
    private String model;
    private int numOfOwners;
    private boolean radioButton;
    private int mpg;

    public car(int parseInt) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
   
    /**
     * @return the ID
     */
  
    public String getID() {
        return ID;
    }

    /**
     * @param ID the ID to set
     */
    public void setID(String ID) {
        this.ID = ID;
    }

    /**
     * @return the year
     */
    public int getYear() {
        return year;
    }

    /**
     * @param year the year to set
     */
    public void setYear(int year) {
        this.year = year;
    }

    /**
     * @return the make
     */
    public String getMake() {
        return make;
    }

    /**
     * @param make the make to set
     */
    public void setMake(String make) {
        this.make = make;
    }

    /**
     * @return the model
     */
    public String getModel() {
        return model;
    }

    /**
     * @param model the model to set
     */
    public void setModel(String model) {
        this.model = model;
    }

    /**
     * @return the numOfOwners
     */
    public int getNumOfOwners() {
        return numOfOwners;
    }

    /**
     * @param numOfOwners the numOfOwners to set
     */
    public void setNumOfOwners(int numOfOwners) {
        this.numOfOwners = numOfOwners;
    }

    /**
     * @return the mpg
     */
    public int getMpg() {
        return mpg;
    }

    /**
     * @param mpg the mpg to set
     */
    public void setMpg(int mpg) {
        this.mpg = mpg;
    }

    /**
     * @return the radioButton
     */
    public boolean isRadioButton() {
        return radioButton;
    }

    /**
     * @param radioButton the radioButton to set
     */
    public void setRadioButton(boolean radioButton) {
        this.radioButton = radioButton;
    }
}
